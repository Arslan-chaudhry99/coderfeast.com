import React from 'react'
import "./style.css"
const Btn = () => {
    return (
        <div className="home_reviews_styling">

        </div>
    )
}

export default Btn