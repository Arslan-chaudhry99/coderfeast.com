import React from 'react'

const Node = () => {
  return (
    <div>Node</div>
  )
}

export default Node