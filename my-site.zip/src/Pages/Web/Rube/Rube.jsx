import React from 'react'

const Rube = () => {
  return (
    <div>Rube</div>
  )
}

export default Rube